---
layout: default
lang: fr_FR
title: Exemple sur les widgets
---

# Exemple avec le plugin virtuel

> - <a href="{{site.baseurl}}/{{site.help}}/{{page.lang}}/config_info">Aide pour le paramétrage des widgets de type info (binaire, numérique, actions)</a>
> - <a href="{{site.baseurl}}/{{site.help}}/{{page.lang}}/config_action">Aide pour le paramétrage des widgets de type action</a>

# Exemple avec le plugin Alarme

> - <a href="{{site.baseurl}}/{{site.help}}/{{page.lang}}/config_plugin_alarm">Exemple d'utilisation des widgets Multi-action et Multi-info avec le plugin Alarme</a>
