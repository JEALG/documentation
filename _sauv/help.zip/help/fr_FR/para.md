---
layout: default
lang: fr_FR
title: Comment ajouter des paramètres
description: Comment ajouter des paramètres
---

[back](./)

# Ajout des paramètres

- Cliquer sur la roue crantée de la commande
<p><img src="../{{site.img}}/config_roue.png" alt="Roue Crantée" width="100"/></p>

- Ensuite sélectionner l'onglet <b><i>Affichage</i></b> (flèche en violet)<br/>
<p><img src="../{{site.img}}/config_onglet_affichage_action.png" alt="Onglet Affichage" width="700" /></p><br/>

- Ajouter les variables en cliquant sur le bouton <b><i>Ajouter</i></b> (flèche en orange)<br/>

<hr />
[back](./)
