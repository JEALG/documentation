---
layout: default
lang: fr_FR
title: Les Widgets
---


Ici vous trouverez l'ensemble de la documentation des Widgets JAG pour Jeedom

# A Savoir

> **Afin de simplifier la gestion des images, depuis le 10/09/2019, il est nécessaire d'avoir le widget "Multi_action-Defaut" pour tous les widgets**<br/>
> Dans chaque widget, un exemple de configuration est disponible

# Aide

> **Afin de simplifier la gestion du site**, depuis le 11/05/2020, la documentation de l'aide a été déplacée<br/>

- [Documentation Aide]({{site.baseurl}}/{{site.help}}/{{page.lang}})


